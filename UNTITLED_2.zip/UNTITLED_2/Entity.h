#ifndef ENTITY_H
#define ENTITY_H

class Entity
{
	public:
	
//========================= CONSTRUCTORS & DESTRUCTORS =========================	
	
		Entity();
		
		virtual ~Entity();
};

#endif // ENTITY_H