#ifndef UNIT_H
#define UNIT_H

#include "Armor.h"
#include "Weapon.h"

class Unit
{
	private:
	
		
	
	public:

//========================= CONSTRUCTORS & DESTRUCTORS =========================	

		Unit();
		
		virtual ~Unit();
};

#endif // UNIT_H