#include "Tile.h"

Tile::Tile(TILE_TYPES _type) : type(_type)
{
	entity = nullptr;
}

Tile::~Tile()
{
	
}